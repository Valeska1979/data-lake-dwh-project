import json
import os
import logging
import urllib.request
import urllib.error
from datetime import datetime, timedelta

import pg8000.native

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# --- Config (set these as Lambda environment variables) ---
GEMINI_API_KEY = os.environ["GEMINI_API_KEY"]
DB_HOST        = os.environ["DB_HOST"]
DB_PORT        = int(os.environ.get("DB_PORT", "5432"))
DB_NAME        = os.environ["DB_NAME"]
DB_USER        = os.environ["DB_USER"]
DB_PASSWORD    = os.environ["DB_PASSWORD"]

GEMINI_URL = (
    "https://generativelanguage.googleapis.com/v1beta/models/"
    "gemini-1.5-pro:generateContent?key=" + GEMINI_API_KEY
)

CREATE_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS geopolitical_events (
    id          SERIAL PRIMARY KEY,
    week_start  DATE NOT NULL,
    event_type  TEXT NOT NULL,
    summary     TEXT NOT NULL,
    created_at  TIMESTAMP DEFAULT NOW()
);
"""

PROMPT_TEMPLATE = """
You are a geopolitical analyst. List the most significant geopolitical events that occurred 
in the week of {week_start} to {week_end}.

Return ONLY a JSON array with no markdown, no explanation, no backticks. Each item must have:
- "event_type": one of [sanctions, military_escalation, diplomatic_talks, elections, 
                        trade_dispute, humanitarian_crisis, treaty, coup, cyber_attack, other]
- "summary": a 2-3 sentence factual description of the event

Example format:
[
  {
    "event_type": "sanctions",
    "summary": "The EU announced a new package of sanctions targeting..."
  }
]
"""


def get_week_range():
    today = datetime.utcnow().date()
    last_monday = today - timedelta(days=today.weekday() + 7)
    last_sunday = last_monday + timedelta(days=6)
    return last_monday, last_sunday


def fetch_events_from_gemini(week_start, week_end):
    prompt = PROMPT_TEMPLATE.format(
        week_start=week_start.strftime("%B %d, %Y"),
        week_end=week_end.strftime("%B %d, %Y"),
    )

    payload = json.dumps({
        "contents": [{"parts": [{"text": prompt}]}],
        "tools": [{"google_search_retrieval": {}}],
    }).encode("utf-8")

    req = urllib.request.Request(
        GEMINI_URL,
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )

    logger.info(f"Calling Gemini for week {week_start} to {week_end}")
    with urllib.request.urlopen(req, timeout=60) as resp:
        result = json.loads(resp.read().decode("utf-8"))

    raw = result["candidates"][0]["content"]["parts"][0]["text"].strip()
    logger.info(f"Gemini raw response: {raw[:500]}")

    if raw.startswith("```"):
        raw = raw.split("```")[1]
        if raw.startswith("json"):
            raw = raw[4:]

    events = json.loads(raw.strip())
    logger.info(f"Parsed {len(events)} events from Gemini")
    return events


def insert_events(events, week_start):
    conn = pg8000.native.Connection(
        host=DB_HOST,
        port=DB_PORT,
        database=DB_NAME,
        user=DB_USER,
        password=DB_PASSWORD,
    )
    try:
        conn.run(CREATE_TABLE_SQL)
        for event in events:
            conn.run(
                "INSERT INTO geopolitical_events (week_start, event_type, summary) "
                "VALUES (:week_start, :event_type, :summary)",
                week_start=week_start,
                event_type=event.get("event_type", "other"),
                summary=event.get("summary", ""),
            )
            logger.info(f"Inserted: [{event.get('event_type')}]")
        logger.info(f"Successfully inserted {len(events)} events.")
    finally:
        conn.close()


def handler(event, context):
    week_start, week_end = get_week_range()
    events = fetch_events_from_gemini(week_start, week_end)
    insert_events(events, week_start)

    return {
        "statusCode": 200,
        "body": json.dumps({
            "week_start": str(week_start),
            "events_inserted": len(events),
        })
    }
